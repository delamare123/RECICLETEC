package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DiagnosticSymptom
import com.example.data.MicrowaveComponent
import com.example.data.RepairDataProvider
import com.example.data.SafetyStep
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.MessageSender
import com.example.viewmodel.RepairViewModel
import com.example.viewmodel.ScreenTab

class MainActivity : ComponentActivity() {
    private val viewModel: RepairViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { AppBottomBar(viewModel) }
                ) { innerPadding ->
                    MainScreenContent(
                        viewModel = viewModel,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

// --- Navigation Bottom Bar ---
@Composable
fun AppBottomBar(viewModel: RepairViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    NavigationBar(
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.testTag("app_navigation_bar")
    ) {
        NavigationBarItem(
            selected = currentTab == ScreenTab.INICIO,
            onClick = { viewModel.selectTab(ScreenTab.INICIO) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Início") },
            label = { Text("Início", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF2E7D32),
                selectedTextColor = Color(0xFF2E7D32)
            ),
            modifier = Modifier.testTag("nav_tab_inicio")
        )
        NavigationBarItem(
            selected = currentTab == ScreenTab.SEGURANCA,
            onClick = { viewModel.selectTab(ScreenTab.SEGURANCA) },
            icon = { Icon(Icons.Default.Shield, contentDescription = "Segurança") },
            label = { Text("Segurança", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFC62828),
                selectedTextColor = Color(0xFFC62828)
            ),
            modifier = Modifier.testTag("nav_tab_seguranca")
        )
        NavigationBarItem(
            selected = currentTab == ScreenTab.DIAGNOSTICO,
            onClick = { viewModel.selectTab(ScreenTab.DIAGNOSTICO) },
            icon = { Icon(Icons.Default.Troubleshoot, contentDescription = "Defeitos") },
            label = { Text("Diagnósticos", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFF57C00),
                selectedTextColor = Color(0xFFF57C00)
            ),
            modifier = Modifier.testTag("nav_tab_diagnostico")
        )
        NavigationBarItem(
            selected = currentTab == ScreenTab.COMPONENTES,
            onClick = { viewModel.selectTab(ScreenTab.COMPONENTES) },
            icon = { Icon(Icons.Default.ElectricBolt, contentDescription = "Componentes") },
            label = { Text("Tabela", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF00796B),
                selectedTextColor = Color(0xFF00796B)
            ),
            modifier = Modifier.testTag("nav_tab_componentes")
        )
        NavigationBarItem(
            selected = currentTab == ScreenTab.SIMULADOR_TESTE,
            onClick = { viewModel.selectTab(ScreenTab.SIMULADOR_TESTE) },
            icon = { Icon(Icons.Default.Calculate, contentDescription = "Multímetro") },
            label = { Text("Multímetro", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFFE65100),
                selectedTextColor = Color(0xFFE65100)
            ),
            modifier = Modifier.testTag("nav_tab_simulador")
        )
        NavigationBarItem(
            selected = currentTab == ScreenTab.ASSISTENTE_IA,
            onClick = { viewModel.selectTab(ScreenTab.ASSISTENTE_IA) },
            icon = { Icon(Icons.Default.SupportAgent, contentDescription = "Reciclotech AI") },
            label = { Text("CE Chat IA", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF1565C0),
                selectedTextColor = Color(0xFF1565C0)
            ),
            modifier = Modifier.testTag("nav_tab_ia")
        )
    }
}

// --- Main Navigation Router ---
@Composable
fun MainScreenContent(viewModel: RepairViewModel, modifier: Modifier = Modifier) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    AnimatedContent(
        targetState = currentTab,
        transitionSpec = {
            fadeIn(animationSpec = tween(150)) togetherWith fadeOut(animationSpec = tween(150))
        },
        label = "tab_transitions",
        modifier = modifier
    ) { targetTab ->
        when (targetTab) {
            ScreenTab.INICIO -> HomeScreen(viewModel)
            ScreenTab.SEGURANCA -> SafetyScreen(viewModel)
            ScreenTab.DIAGNOSTICO -> DiagnosticsScreen(viewModel)
            ScreenTab.COMPONENTES -> ComponentsScreen(viewModel)
            ScreenTab.SIMULADOR_TESTE -> MultimeterSimulatorScreen(viewModel)
            ScreenTab.ASSISTENTE_IA -> AiAssistantScreen(viewModel)
        }
    }
}

// ==========================================
// SCREEN 1: HOME SCREEN / INÍCIO (Reciclotech)
// ==========================================
@Composable
fun HomeScreen(viewModel: RepairViewModel) {
    val safetyAnswers by viewModel.completedSafetyIds.collectAsStateWithLifecycle()
    val totalSafetyChecklist = RepairDataProvider.safetySteps.size
    val isFullySafe = safetyAnswers.size == totalSafetyChecklist

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Aesthetic Brand Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF1B5E20), Color(0xFF2E7D32), Color(0xFF43A047))
                        )
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Eco,
                            contentDescription = null,
                            tint = Color(0xFFC8E6C9),
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "CE RECICLETEC",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 26.sp,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Centro Ecológico e Guia de Reparos de Micro-ondas",
                        fontSize = 15.sp,
                        color = Color(0xFFE8F5E9),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Foco em conserto seguro, reciclagem de cobre, descarte inteligente e treinamento técnico sem desperdício.",
                            fontSize = 12.sp,
                            color = Color.White,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        // Safety Interlock Status Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isFullySafe) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = if (isFullySafe) Color(0xFF81C784) else Color(0xFFEF5350),
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (isFullySafe) Color(0xFF2E7D32) else Color(0xFFC62828)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isFullySafe) Icons.Default.Check else Icons.Default.PriorityHigh,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isFullySafe) "Ambiente Seguro de Trabalho" else "Segurança Requer Atenção!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isFullySafe) Color(0xFF1B5E20) else Color(0xFFB71C1C)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isFullySafe)
                                "Você validou todos os procedimentos cruciais de isolamento térmico e elétrico!"
                            else
                                "Por favor, visite a aba 'Segurança' e complete o checklist de descarga do capacitor para mitigar riscos de choque elétrico fatal.",
                            fontSize = 12.sp,
                            color = if (isFullySafe) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }
                }
            }
        }

        // Ecotech Statistics Cards Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Impacto Ecológico CE RECICLETEC 2026",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ImpactStatCard(
                        title = "Cobre Recuperado",
                        value = "64,2 kg",
                        subtext = "De trafos e cabos",
                        icon = Icons.Default.ElectricBolt,
                        color = Color(0xFFEF6C00),
                        modifier = Modifier.weight(1f)
                    )
                    ImpactStatCard(
                        title = "Lixo Eletrônico Evitado",
                        value = "342 kg",
                        subtext = "Em carcaças e placas",
                        icon = Icons.Default.Recycling,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ImpactStatCard(
                        title = "Aparelhos Salvos",
                        value = "189 und.",
                        subtext = "Recondicionados",
                        icon = Icons.Default.Memory,
                        color = Color(0xFF1565C0),
                        modifier = Modifier.weight(1f)
                    )
                    ImpactStatCard(
                        title = "Alunos Treinados",
                        value = "120 técnicos",
                        subtext = "Ensino sustentável",
                        icon = Icons.Default.School,
                        color = Color(0xFF6A1B9A),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Sustainable Quick tip
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = Color(0xFFFFA000)
                        )
                        Text(
                            text = "Por que não temos Ordens de Serviço?",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "O CE RECICLETEC é um projeto educacional voltado à capacitação eletrônica e reciclagem inteligente de resíduos eletrônicos. Não coletamos dados de clientes nem geramos ordens de faturamentos de serviços. Fornecemos ferramentas de bancada livres de burocracia para diagnosticar e evitar o descarte incorreto de fornos na natureza.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ImpactStatCard(
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Text(text = subtext, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


// ==========================================
// SCREEN 2: SAFETY SCREEN / SEGURANÇA ELÉTRICA
// ==========================================
@Composable
fun SafetyScreen(viewModel: RepairViewModel) {
    val completedSafetyIds by viewModel.completedSafetyIds.collectAsStateWithLifecycle()
    val steps = RepairDataProvider.safetySteps

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Perigo",
                        tint = Color(0xFFC62828),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "Segurança na Bancada",
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color(0xFFC62828)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Fornos micro-ondas contêm energia acumulada letal mesmo completamente desconectados da tomada de energia elétrica. Garanta que todo conserto comece com a descarga obrigatória do capacitor.",
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(steps) { step ->
            val isChecked = completedSafetyIds.contains(step.id)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isChecked) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.toggleSafetyStep(step.id) }
                    .border(
                        width = 1.dp,
                        color = if (isChecked) Color(0xFF81C784) else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .testTag("safety_card_${step.id}")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { viewModel.toggleSafetyStep(step.id) },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2E7D32)),
                        modifier = Modifier.testTag("safety_checkbox_${step.id}")
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${step.id}. ${step.title}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (isChecked) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = step.description,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = if (isChecked) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFFFECEB))
                    .border(1.dp, Color(0xFFEF9A9A), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Report,
                            contentDescription = null,
                            tint = Color(0xFFC62828)
                        )
                        Text(
                            text = "REGRA GERAL DO CE RECICLETEC",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFFC62828)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Nunca tente medir nenhuma linha de alta voltagem (Magnetron, Capacitor, Transformador Secundário) com o micro-ondas ligado à tomada elétrica convencional. Multímetros residenciais queimarão na hora e explodirão sob a carga de 4.000V AC/CC.",
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = Color(0xFFB71C1C)
                    )
                }
            }
        }
    }
}


// ==========================================
// SCREEN 3: DIAGNOSTICS SCREEN / DEFEITOS
// ==========================================
@Composable
fun DiagnosticsScreen(viewModel: RepairViewModel) {
    val selectedSymptom by viewModel.selectedSymptom.collectAsStateWithLifecycle()
    val completedSteps by viewModel.completedSteps.collectAsStateWithLifecycle()
    val symptoms = RepairDataProvider.symptoms

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (selectedSymptom == null) {
            // Symptom Selection Menu
            item {
                Column {
                    Text(
                        text = "Diagnóstico Interativo de Sintomas",
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Selecione o sintoma que o aparelho de micro-ondas apresenta na bancada para ver o fluxograma de testes de componentes e dicas inteligentes.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(symptoms) { symptom ->
                val checks = completedSteps[symptom.id]?.size ?: 0
                val totalSteps = symptom.checklistSteps.size

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectSymptom(symptom) }
                        .testTag("symptom_item_${symptom.id}"),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = Color(0xFFF57C00)
                                )
                                Text(
                                    text = symptom.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = symptom.description,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                        if (checks > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Efetuado $checks de $totalSteps verificações",
                                    fontSize = 11.sp,
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Detailed View of Selected Symptom
            val symptom = selectedSymptom!!
            val checkedSet = completedSteps[symptom.id] ?: emptySet()

            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { viewModel.selectSymptom(null) }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        tint = Color(0xFFF57C00)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Voltar aos Sintomas",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF57C00)
                    )
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = symptom.title,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = symptom.description,
                            fontSize = 13.sp,
                            color = Color(0xFF5D4037)
                        )
                    }
                }
            }

            // Suspect Components Linking
            item {
                Column {
                    Text(
                        text = "Componentes Suspeitos Principais",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(symptom.possibleCauses) { causeId ->
                            val comp = RepairDataProvider.components.find { it.id == causeId }
                            if (comp != null) {
                                Surface(
                                    color = Color(0xFFE0F2F1),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .clickable {
                                            viewModel.selectComponent(comp)
                                            viewModel.selectTab(ScreenTab.COMPONENTES)
                                        }
                                        .border(1.dp, Color(0xFF80CBC4), RoundedCornerShape(12.dp))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Construction,
                                            contentDescription = null,
                                            tint = Color(0xFF00796B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = comp.name,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF004D40)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Checklist Steps Action Grid
            item {
                Text(
                    text = "Passos de Verificação Recomendados",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            itemsIndexed(symptom.checklistSteps) { idx, step ->
                val isChecked = checkedSet.contains(idx)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isChecked) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleSymptomStep(symptom.id, idx) }
                        .border(
                            width = 1.dp,
                            color = if (isChecked) Color(0xFF81C784) else MaterialTheme.colorScheme.outlineVariant,
                            shape = RoundedCornerShape(12.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { viewModel.toggleSymptomStep(symptom.id, idx) },
                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2E7D32)),
                            modifier = Modifier.testTag("step_check_${symptom.id}_$idx")
                        )
                        Text(
                            text = step,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = if (isChecked) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Green Recycling EcoTip Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Recycling,
                            contentDescription = "EcoTip",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "Pegada Ecológica & Reaproveitamento",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = symptom.recyclingEcoTip,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// SCREEN 4: COMPONENTS LIBRARY / TABELA
// ==========================================
@Composable
fun ComponentsScreen(viewModel: RepairViewModel) {
    val selectedComponent by viewModel.selectedComponent.collectAsStateWithLifecycle()
    val components = RepairDataProvider.components

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (selectedComponent == null) {
            item {
                Column {
                    Text(
                        text = "Biblioteca de Componentes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Consulte as leituras padrões de multímetro, sintomas de falha, riscos de segurança e métodos de reciclagem educacional adotados no CE RECICLETEC.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(components) { comp ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectComponent(comp) }
                        .testTag("comp_item_${comp.id}"),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFE0F2F1)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ElectricBolt,
                                contentDescription = null,
                                tint = Color(0xFF00796B)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = comp.portugueseName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = comp.function,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        } else {
            val comp = selectedComponent!!

            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { viewModel.selectComponent(null) }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Voltar",
                        tint = Color(0xFF00796B)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Voltar aos Componentes",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00796B)
                    )
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2F1)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = comp.portugueseName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF004D40)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = comp.description,
                            fontSize = 13.sp,
                            color = Color(0xFF00796B),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Tech specs block
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TechHeader("Função Básica")
                    BodyText(comp.function)

                    TechHeader("Sintoma de Falha mais Frequente")
                    BodyText(comp.commonSymptoms)

                    TechHeader("Como Testar com Multímetro")
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = comp.testingInstructions,
                            fontSize = 13.sp,
                            lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    TechHeader("Valores Esperados (Medições Saudáveis)")
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE8F5E9))
                            .border(1.dp, Color(0xFF81C784), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF2E7D32)
                            )
                            Text(
                                text = comp.expectedReadings,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20)
                            )
                        }
                    }

                    TechHeader("Riscos e Precauções de Segurança na Bancada")
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFFEBEE))
                            .border(1.dp, Color(0xFFEF9A9A), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.CrisisAlert,
                                contentDescription = null,
                                tint = Color(0xFFC62828)
                            )
                            Text(
                                text = comp.safetyHazard,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = Color(0xFFB71C1C)
                            )
                        }
                    }

                    TechHeader("Instruções de Reciclagem Sustentável CE RECICLETEC")
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF3E5F5))
                            .border(1.dp, Color(0xFFD1C4E9), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Nature,
                                contentDescription = null,
                                tint = Color(0xFF6A1B9A)
                            )
                            Column {
                                Text(
                                    text = "Reúso Educacional / Ecológico de Peças:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF4A148C)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = comp.recyclingInfo,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = Color(0xFF4A148C)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TechHeader(text: String) {
    Text(
        text = text,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 4.dp).padding(top = 8.dp)
    )
}

@Composable
fun BodyText(text: String) {
    Text(
        text = text,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}


// ==========================================
// SCREEN 5: MULTIMETER SIMULATOR / CALCULADORA
// ==========================================
@Composable
fun MultimeterSimulatorScreen(viewModel: RepairViewModel) {
    val selectedCompId by viewModel.selectedCalculatorCompId.collectAsStateWithLifecycle()
    val rFilament by viewModel.resistanceFilament.collectAsStateWithLifecycle()
    val rGround by viewModel.resistanceGround.collectAsStateWithLifecycle()
    val simResult by viewModel.simulationResult.collectAsStateWithLifecycle()

    val keyboardController = LocalSoftwareKeyboardController.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Avaliador Digital de Multímetro",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Digite os valores medidos nas chaves do multímetro analógico ou digital na bancada. O sistema dará um veredito de conserto com base nas tolerâncias térmicas de engenharia.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Component selector pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val menuItems = listOf(
                    "magnetron" to "Magnetron",
                    "capacitor" to "Capacitor",
                    "transformer" to "Trafo (Transformador)",
                    "diodo" to "Diodo"
                )
                items(menuItems) { (id, label) ->
                    val isSel = id == selectedCompId
                    FilterChip(
                        selected = isSel,
                        onClick = { viewModel.selectCalculatorComponent(id) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFE65100),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_chip_$id")
                    )
                }
            }
        }

        // Selected component advice
        item {
            val componentTitle = when (selectedCompId) {
                "magnetron" -> "Análise do Magnetron Osmar"
                "capacitor" -> "Análise do Capacitor de Alta Voltagem"
                "transformer" -> "Análise das Bobinas do Transformador Heavy-Trafo"
                "diodo" -> "Análise do Diodo de Alta Fuselagem"
                else -> ""
            }

            Text(
                text = componentTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFFE65100)
            )
        }

        // Input Fields Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val filamentPlaceholder = when (selectedCompId) {
                        "magnetron" -> "Ex: 0.5 (Valor esperado abaixo de 1 Ω)"
                        "capacitor" -> "Ex: OL ou 10000000 (Megohms do resistor interno)"
                        "transformer" -> "Ex: 1.8 (Enrolamento primário esperado: 1~3 Ω)"
                        "diodo" -> "Ex: 'OL' ou 'aberto' (Não bipa nos dois lados)"
                        else -> "Ex: 0"
                    }

                    val fLabel = when (selectedCompId) {
                        "transformer" -> "Resistência do Enrolamento Primário (Ω)"
                        "capacitor" -> "Resistência entre os Terminais (Ω ou escreva OL)"
                        else -> "Resistência entre os Terminais / Filamentos (Ω)"
                    }

                    // Reading 1: Filament/Terminals
                    Column {
                        Text(
                            text = fLabel,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = rFilament,
                            onValueChange = { viewModel.resistanceFilament.value = it },
                            placeholder = { Text(filamentPlaceholder, fontSize = 12.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calculator_filament_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFE65100),
                                focusedLabelColor = Color(0xFFE65100)
                            )
                        )
                    }

                    // Reading 2: Ground isolation check
                    val groundPlaceholder = when (selectedCompId) {
                        "magnetron" -> "Escreva OL ou infinito para OK"
                        "capacitor" -> "OL ou acima de 500.000 Ω"
                        "transformer" -> "Escreva a medição do Secundário (esperado: 60~120 Ω)"
                        "diodo" -> "Usou bateria de 9v em série? (bipa ou acende só de 1 lado)"
                        else -> "OL"
                    }

                    val gLabel = when (selectedCompId) {
                        "transformer" -> "Resistência do Secundário (Saída de Alta para Carcaça em Ω)"
                        "diodo" -> "Medição reversa ou Bip convencional (bipa? sim ou não)"
                        else -> "Medição de Isolação para a Carcaça (Ω ou escreva OL)"
                    }

                    Column {
                        Text(
                            text = gLabel,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = rGround,
                            onValueChange = { viewModel.resistanceGround.value = it },
                            placeholder = { Text(groundPlaceholder, fontSize = 12.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    keyboardController?.hide()
                                    viewModel.runComponentSimulation()
                                }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFE65100),
                                focusedLabelColor = Color(0xFFE65100)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calculator_ground_input")
                        )
                    }

                    Button(
                        onClick = {
                            keyboardController?.hide()
                            viewModel.runComponentSimulation()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("trigger_simulation_button")
                    ) {
                        Icon(imageVector = Icons.Default.Analytics, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Executar Avaliação Técnica", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Simulation Outcome Banner
        if (simResult != null) {
            val res = simResult!!
            val hexColor = Color(android.graphics.Color.parseColor(res.statusColorHex))

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = hexColor.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, hexColor, RoundedCornerShape(16.dp))
                        .testTag("simulation_result_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (res.isSuccess) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                contentDescription = null,
                                tint = hexColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = res.statusLabel,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = hexColor
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = res.explanation,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// SCREEN 6: GEMINI AI ASSISTANT / CHAT
// ==========================================
@Composable
fun AiAssistantScreen(viewModel: RepairViewModel) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isChatLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()
    val chatInput by viewModel.chatInputText.collectAsStateWithLifecycle()

    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App bar intro inside column
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color(0xFF1565C0),
                modifier = Modifier.size(28.dp)
            )
            Column {
                Text(
                    text = "Aconselhamento CE Chat IA",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Suporte de Diagnóstico do CE RECICLETEC",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Divider(modifier = Modifier.padding(vertical = 4.dp))

        // Chat message list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            reverseLayout = false,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            // Suggestion chips when chat is clean
            if (messages.size <= 1) {
                item {
                    Text(
                        text = "Perguntas Frequentes de Bancada:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        QuickSuggestionChip(
                            text = "Como esvaziar o capacitor com total segurança?"
                        ) {
                            viewModel.chatInputText.value = "Como esvaziar o capacitor com total segurança?"
                            viewModel.submitChatMessage()
                        }
                        QuickSuggestionChip(
                            text = "Aparelho funciona sem esquentar, o que testar?"
                        ) {
                            viewModel.chatInputText.value = "Aparelho funciona sem esquentar, o que testar?"
                            viewModel.submitChatMessage()
                        }
                        QuickSuggestionChip(
                            text = "Como o CE RECICLETEC recicla bobinas dos Trafos?"
                        ) {
                            viewModel.chatInputText.value = "Como o CE RECICLETEC recicla as bobinas de cobre do transformador?"
                            viewModel.submitChatMessage()
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            items(messages) { msg ->
                ChatBubble(message = msg)
            }

            if (isChatLoading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF1565C0)
                                )
                                Text(
                                    text = "Professor Recicletec processando...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF1565C0)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Message input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding(), // extra bottom-pad to clear gesture navigation keys
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = chatInput,
                onValueChange = { viewModel.chatInputText.value = it },
                placeholder = { Text("Fórmula de curto, dicas de reciclagem...", fontSize = 13.sp) },
                maxLines = 3,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = {
                        keyboardController?.hide()
                        viewModel.submitChatMessage()
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_text"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF1565C0),
                    focusedLabelColor = Color(0xFF1565C0)
                ),
                shape = RoundedCornerShape(24.dp)
            )

            IconButton(
                onClick = {
                    keyboardController?.hide()
                    viewModel.submitChatMessage()
                },
                enabled = chatInput.isNotBlank() && !isChatLoading,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (chatInput.isNotBlank() && !isChatLoading) Color(0xFF1565C0) else Color.Gray.copy(alpha = 0.2f)
                    )
                    .testTag("send_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Enviar",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
fun QuickSuggestionChip(text: String, onClick: () -> Unit) {
    Surface(
        color = Color(0xFFE3F2FD),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = Color(0xFF1565C0),
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = text,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0D47A1)
            )
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val containerColor = if (isUser) Color(0xFF1565C0) else Color(0xFFECEFF1)
    val contentColor = if (isUser) Color.White else Color(0xFF263238)

    val label = if (isUser) "Você" else "IA RECICLETEC 🤖"
    val labelColor = if (isUser) Color(0xFF1E88E5) else Color(0xFF37474F)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = labelColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 0.dp,
                        bottomEnd = if (isUser) 0.dp else 16.dp
                    )
                )
                .background(containerColor)
                .padding(12.dp)
        ) {
            Text(
                text = message.text,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                color = contentColor
            )
        }
    }
}

package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Content
import com.example.api.GeminiRequest
import com.example.api.Part
import com.example.api.GenerationConfig
import com.example.api.RetrofitClient
import com.example.data.DiagnosticSymptom
import com.example.data.MicrowaveComponent
import com.example.data.RepairDataProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ScreenTab {
    INICIO,
    SEGURANCA,
    DIAGNOSTICO,
    COMPONENTES,
    SIMULADOR_TESTE,
    ASSISTENTE_IA
}

data class ChatMessage(
    val id: String,
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    USER,
    SYSTEM,
    AI
}

// Result class for component simulator
data class SimulationResult(
    val isSuccess: Boolean,
    val statusLabel: String,
    val statusColorHex: String,
    val explanation: String
)

class RepairViewModel : ViewModel() {

    // Tab Navigation State
    private val _currentTab = MutableStateFlow(ScreenTab.INICIO)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    // Diagnostic state
    private val _selectedSymptom = MutableStateFlow<DiagnosticSymptom?>(null)
    val selectedSymptom: StateFlow<DiagnosticSymptom?> = _selectedSymptom.asStateFlow()

    // Toggled steps for each symptom checklist: map of Symbol ID to Set of checked step index
    private val _completedSteps = MutableStateFlow<Map<String, Set<Int>>>(emptyMap())
    val completedSteps: StateFlow<Map<String, Set<Int>>> = _completedSteps.asStateFlow()

    // Component library state
    private val _selectedComponent = MutableStateFlow<MicrowaveComponent?>(null)
    val selectedComponent: StateFlow<MicrowaveComponent?> = _selectedComponent.asStateFlow()

    // Safety checks marked as completed
    private val _completedSafetyIds = MutableStateFlow<Set<Int>>(emptySet())
    val completedSafetyIds: StateFlow<Set<Int>> = _completedSafetyIds.asStateFlow()

    // ---- Multimeter Simulator State ----
    private val _selectedCalculatorCompId = MutableStateFlow("magnetron")
    val selectedCalculatorCompId: StateFlow<String> = _selectedCalculatorCompId.asStateFlow()

    // Input values for simulator
    val resistanceFilament = MutableStateFlow("")  // reading 1
    val resistanceGround = MutableStateFlow("")     // reading 2 (infinity, or low)
    
    // Result of multimeter simulation
    private val _simulationResult = MutableStateFlow<SimulationResult?>(null)
    val simulationResult: StateFlow<SimulationResult?> = _simulationResult.asStateFlow()

    // ---- IA Assistant Chat State ----
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                id = "welcome",
                sender = MessageSender.AI,
                text = "Olá! Eu sou o assistente virtual CE RECICLETEC. Como posso ajudar você no diagnóstico ou descarte sustentável do seu micro-ondas hoje?\n\nPergunte-me sobre falhas comuns, como testar um componente, ou como reciclar bobinas de cobre de forma inteligente!"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    val chatInputText = MutableStateFlow("")

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun selectSymptom(symptom: DiagnosticSymptom?) {
        _selectedSymptom.value = symptom
    }

    fun toggleSymptomStep(symptomId: String, stepIndex: Int) {
        val currentMap = _completedSteps.value.toMutableMap()
        val currentSet = currentMap[symptomId]?.toMutableSet() ?: mutableSetOf()
        if (currentSet.contains(stepIndex)) {
            currentSet.remove(stepIndex)
        } else {
            currentSet.add(stepIndex)
        }
        currentMap[symptomId] = currentSet
        _completedSteps.value = currentMap
    }

    fun selectComponent(component: MicrowaveComponent?) {
        _selectedComponent.value = component
    }

    fun toggleSafetyStep(stepId: Int) {
        val current = _completedSafetyIds.value.toMutableSet()
        if (current.contains(stepId)) {
            current.remove(stepId)
        } else {
            current.add(stepId)
        }
        _completedSafetyIds.value = current
    }

    fun selectCalculatorComponent(compId: String) {
        _selectedCalculatorCompId.value = compId
        resistanceFilament.value = ""
        resistanceGround.value = ""
        _simulationResult.value = null
    }

    fun runComponentSimulation() {
        val compId = _selectedCalculatorCompId.value
        val fValStr = resistanceFilament.value.trim()
        val gValStr = resistanceGround.value.trim()

        val fVal = fValStr.toDoubleOrNull()
        val isGroundOL = gValStr.equals("OL", ignoreCase = true) || gValStr.equals("infinito", ignoreCase = true) || gValStr.isEmpty()
        val gVal = if (isGroundOL) null else gValStr.toDoubleOrNull()

        if (fValStr.isEmpty()) {
            _simulationResult.value = SimulationResult(
                isSuccess = false,
                statusLabel = "Dados Incompletos",
                statusColorHex = "#E53935",
                explanation = "Por favor, digite o valor medido nos terminais do componente (ou bip)."
            )
            return
        }

        val result = when (compId) {
            "magnetron" -> {
                if (fVal == null) {
                    SimulationResult(false, "Erro de valor", "#E53935", "O valor dos terminais deve ser um número ou 0.")
                } else if (fVal > 1.5) {
                    SimulationResult(
                        isSuccess = false,
                        statusLabel = "FILAMENTO ABERTO / ALTA RECONDUÇÃO",
                        statusColorHex = "#D32F2F",
                        explanation = "Defeito! A resistência do filamento do Magnetron deve ser extremamente baixa (< 1.0 Ω). Se der valor muito alto ou aberto, o filamento rompeu e o magnetron não aquecerá."
                    )
                } else if (!isGroundOL && gVal != null && gVal < 100000.0) {
                    SimulationResult(
                        isSuccess = false,
                        statusLabel = "CURTO-CIRCUITO COM O TERRA",
                        statusColorHex = "#D32F2F",
                        explanation = "Extremo perigo! Há um curto entre os filamentos e a carcaça de metal. Isso causará queima imediata do fusível e risco de eletrocussão caso o aterramento esteja falho. Descarte ou troque imediatamente!"
                    )
                } else {
                    SimulationResult(
                        isSuccess = true,
                        statusLabel = "MAGNETRON BOM / OK",
                        statusColorHex = "#2E7D32",
                        explanation = "Leitura ideal! Terminais conduzindo perfeitamente (~$fVal Ω) e isolamento perfeito em relação à carcaça (infinito). Pronto para reuso!"
                    )
                }
            }
            "capacitor" -> {
                val isTerminalOpen = fValStr.equals("OL", ignoreCase = true) || fValStr.equals("infinito", ignoreCase = true)
                val testVal = fVal ?: 0.0
                if (fValStr.isEmpty()) {
                    SimulationResult(false, "Preencha", "#E53935", "Dados incompletos.")
                } else if (!isTerminalOpen && testVal < 100.0) {
                    SimulationResult(
                        isSuccess = false,
                        statusLabel = "CAPACITOR EM CURTO",
                        statusColorHex = "#D32F2F",
                        explanation = "Defeito grave! O capacitor apresenta baixa resistência entre seus dois pólos. Isso causará sobrecarga instantânea no Trafo e estopim do fusível principal de 20A. Descarte ecologicamente e não use!"
                    )
                } else if (!isGroundOL && gVal != null && gVal < 500000.0) {
                    SimulationResult(
                        isSuccess = false,
                        statusLabel = "FUGA PARA CARCAÇA",
                        statusColorHex = "#D32F2F",
                        explanation = "Defeituoso! Há passagem de energia elétrica para o invólucro metálico do capacitor. Descarte imediato."
                    )
                } else {
                    SimulationResult(
                        isSuccess = true,
                        statusLabel = "CAPACITOR BOM / OK",
                        statusColorHex = "#2E7D32",
                        explanation = "Leitura excelente! O capacitor apresenta excelente isolamento e resistência interna no patamar dos Megaohms (resistor de descarga de ~10 MΩ funcional). Pronto para operar."
                    )
                }
            }
            "transformer" -> {
                if (fVal == null) {
                     SimulationResult(false, "Erro", "#E53935", "Insira a resistência do enrolamento primário em ohms.")
                } else if (fVal < 0.3) {
                     SimulationResult(
                         isSuccess = false,
                         statusLabel = "PRIMÁRIO EM CURTO",
                         statusColorHex = "#D32F2F",
                         explanation = "Defeito! O enrolamento primário do Trafo está em curto-circuito interno (as espiras esquentaram e derreteram o verniz isolante). Irá aquecer, soltar fumaça e desarmar o disjuntor da casa."
                     )
                } else if (fVal > 15.0) {
                     SimulationResult(
                         isSuccess = false,
                         statusLabel = "PRIMÁRIO ABERTO",
                         statusColorHex = "#D32F2F",
                         explanation = "Defeito! O enrolamento primário está partido (aberto). Não circula corrente e o aparelho não vai gerar alta voltagem."
                     )
                } else if (!isGroundOL && gVal != null && (gVal < 50.0 || gVal > 150.0)) {
                     SimulationResult(
                         isSuccess = false,
                         statusLabel = "SECUNDÁRIO DE ALTA ANÔMALO",
                         statusColorHex = "#D16D00",
                         explanation = "Atenção: A resistência do enrolamento secundário deve estar entre 60 Ω e 120 Ω medidos da saída de alta para a carcaça. Uma leitura fora disso indica enrolamento danificado."
                     )
                } else {
                     SimulationResult(
                         isSuccess = true,
                         statusLabel = "TRANSFORMADOR BOM / OK (Excelente para Reúso)",
                         statusColorHex = "#2E7D32",
                         explanation = "Enrolamentos em perfeito estado elétrico! Esse transformador pesado de ferro silício pode ser reciclado pelo CE RECICLETEC para construir uma máquina de solda ponto ecológica de 800W!"
                     )
                }
            }
            "diodo" -> {
                // Diode measurement: common multimeters show OL in both sides unless configured with a 9v series battery circuit.
                val isBip = fValStr.equals("curto", ignoreCase = true) || fValStr.equals("0", ignoreCase = true) || (fVal != null && fVal < 50.0)
                if (isBip) {
                    SimulationResult(
                        isSuccess = false,
                        statusLabel = "DIODO EM CURTO",
                        statusColorHex = "#D32F2F",
                        explanation = "Defeito! O diodo de alta tensão rompeu e virou um mero fio (bipa em ambas as direções). O capacitor não duplicará a carga e o fusível ou o trafo sofrerão sobrecarga. Trocar peça."
                    )
                } else if (fValStr.contains("OL", ignoreCase = true) || fValStr.contains("aberto", ignoreCase = true) || fValStr.contains("ok", ignoreCase = true)) {
                    SimulationResult(
                        isSuccess = true,
                        statusLabel = "DIODO BOM (Isolamento Normal / OK)",
                        statusColorHex = "#2E7D32",
                        explanation = "Leitura correta! Em multímetros comuns de 3V, o teste convencional acusa aberto nos dois sentidos devido à alta queda de tensão interna (~6V) típica de diodos de alta. Se não bipa, está adequado."
                    )
                } else {
                    SimulationResult(
                        isSuccess = true,
                        statusLabel = "TESTE COM BATERIA OK",
                        statusColorHex = "#2E7D32",
                        explanation = "Se você usou o teste de circuito série com bateria de 9V e a lâmpada acendeu em apenas um sentido, o diodo está 100% perfeito."
                    )
                }
            }
            else -> {
                SimulationResult(true, "Análise Padrão", "#757575", "Componente analisado conforme diretrizes padrão do eletrotécnico.")
            }
        }
        _simulationResult.value = result
    }

    fun submitChatMessage() {
        val queryText = chatInputText.value.trim()
        if (queryText.isEmpty()) return

        // Add user message
        val userMsg = ChatMessage(
            id = System.currentTimeMillis().toString() + "_u",
            sender = MessageSender.USER,
            text = queryText
        )
        _chatMessages.value = _chatMessages.value + userMsg
        chatInputText.value = ""
        _isChatLoading.value = true

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                val isApiKeyPlaceholder = apiKey == "MY_GEMINI_API_KEY" || apiKey.isBlank()

                val apiResponseText = if (isApiKeyPlaceholder) {
                    // Use realistic fallback expert response simulator
                    // matching typical problems
                    withContext(Dispatchers.Default) {
                        simulateLocalResponse(queryText)
                    }
                } else {
                    withContext(Dispatchers.IO) {
                        try {
                            val systemPrompt = "Você é o instrutor e assistente especialista de conserto de micro-ondas do 'CE RECICLETEC' (Centro Ecológico e Escola de Reciclagem de Eletrônicos). Forneça respostas técnicas precisas, focando na segurança (esvaziamento do capacitor), na identificação e testes de componentes por multímetro (Magnetron, Trafo, etc.) e na reciclagem sustentável comercial ou pedagógica das peças (ex: recuperar cobre, criar soldadores caseiros). NUNCA forneça ordens de serviço ou planilhas de atendimento, pois este app não lida com ordens de serviços. Responda de forma simples, objetiva e pedagógica em português brasileiro."
                            
                            val req = GeminiRequest(
                                contents = listOf(Content(parts = listOf(Part(text = queryText)))),
                                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                                generationConfig = GenerationConfig(temperature = 0.5f, maxOutputTokens = 1000)
                            )
                            val resp = RetrofitClient.service.generateContent(apiKey, req)
                            resp.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                                ?: "Não consegui obter uma resposta técnica do servidor Gemini. Por favor, tente novamente."
                        } catch (e: Exception) {
                            "Ops! Ocorreu um erro na conexão de rede: ${e.message}. Fornecendo simulação recomendada:\n\n" + simulateLocalResponse(queryText)
                        }
                    }
                }

                _chatMessages.value = _chatMessages.value + ChatMessage(
                    id = System.currentTimeMillis().toString() + "_ai",
                    sender = MessageSender.AI,
                    text = apiResponseText
                )
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    private fun simulateLocalResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("capacit") || q.contains("choque") || q.contains("descarreg") -> {
                "⚠️ **DIAGNÓSTICO CE RECICLETEC - SEGURANÇA MÁXIMA**:\n\n" +
                "O capacitor de alta voltagem acumula carga perigosíssima (até 4000V de corrente contínua). Mesmo desligando o aparelho da tomada, ele pode reter essa eletricidade e causar parada cardíaca.\n\n" +
                "**Como esvaziar de maneira segura:**\n" +
                "1. Certifique-se de que o aparelho está totalmente desplugado da tomada.\n" +
                "2. Use uma chave de fenda robusta profissional isolada para 1000V.\n" +
                "3. Conecte um cabo jacaré no corpo metálico da chave de fenda e prenda a outra extremidade no chassi de metal do micro-ondas (aterramento).\n" +
                "4. Toque com a ponta da chave em um dos terminais do capacitor por 5 segundos. Faça o mesmo no outro terminal.\n" +
                "5. Em seguida, curto-circuite os dois terminais do capacitor encostando a chave em ambos simultaneamente.\n\n" +
                "♻️ **ECOLOGIA**: Um capacitor defeituoso deve ser enviado para pontos ecológicos de destinação de componentes químicos industriais."
            }
            q.contains("magnetron") || q.contains("não esquenta") -> {
                "⚡ **ASSISTÊNCIA CE RECICLETEC - MAGNETRON**:\n\n" +
                "O Magnetron é responsável por gerar as micro-ondas. Se o aparelho está ligando, girando o prato, mas não aquece nada, as causas mais prováveis são o Magnetron enfraquecido/curto ou o diodo de alta queimado.\n\n" +
                "**Como testar seus terminais:**\n" +
                "- Meça a resistência nos terminais do filamento (deve bipar, abaixo de 1 ohm).\n" +
                "- Meça de cada terminal para a carcaça de alumínio do Magnetron (escala de Mohms: deve dar infinito completa). Qualquer valor numérico indica curto-circuito na carcaça.\n\n" +
                "♻️ **Sustentabilidade**: Um magnetron quebrado possui dois ímãs de neodímio/ferrite gigantescos e anéis de cobre puro. No CE RECICLETEC, nós retiramos esses ímãs para uso em aerofólios de mini-geradores de energia ou chaves magnéticas pedagógicas!"
            }
            q.contains("fusivel") || q.contains("fusível") || q.contains("desliga") -> {
                "🔌 **DIAGNÓSTICO DE PROTEÇÃO - FUSÍVEL**:\n\n" +
                "A queima do Fusível de Entrada (normalmente 20A cerâmico) desliga o aparelho inteiro de imediato. Isso ocorre por um curto circuito severo.\n\n" +
                "**O que causa a queima do fusível:**\n" +
                "1. **Microchaves da porta desalinhadas**: Se a chave monitoradora armar antes da primária abrir, ocorre um curto-circuito planejado de segurança que abre o fusível para evitar que as micro-ondas escapem.\n" +
                "2. **Capacitor em curto**: Descarregue o capacitor e meça seus terminais. Se der curto circuito direto, ele está matando o fusível.\n" +
                "3. **Curto no enrolamento primário do Transformador de Alta Voltagem (Trafo)**.\n\n" +
                "⚠️ *Dica Ecológica*: Sempre descubra a causa antes de trocar o fusível, pois relançar um novo fusível sem consertar causará outra queima imediata e desperdício de insumos."
            }
            q.contains("recicla") || q.contains("eco") || q.contains("reaproveita") || q.contains("trafo") || q.contains("solda") -> {
                "♻️ **RECICLAGEM E SUSTENTABILIDADE - PROPOSTA CE RECICLETEC**:\n\n" +
                "Micro-ondas velhos são minas de ouro para o reaproveitamento tecnológico! Veja o que extraímos no nosso Centro Ecológico:\n\n" +
                "1. **Transformador de Alta (Trafo)**: É composto por cerca de 600g de fios de cobre esmaltado ou alumínio e chapas pesadas de ferro silício. No CE RECICLETEC, removemos o secundário de alta voltagem e rebobinamos com cabo grosso de 10mm² para montar **fontes de alta corrente** e **máquinas de solda ponto ecológica** de alta potência para baterias de lítio.\n" +
                "2. **Motor Síncrono do Prato**: Atua com 110V/220V e roda lento. Perfeito para churrasqueiras automáticas, secadores de carretéis, agitadores de líquidos, ou espetos giratórios.\n" +
                "3. **Gabinete de Chapa de Aço**: Pode ser pintado e transformado em caixas protetoras de ferramentas, caixas de correio de alta resistência, ou caixas elétricas industriais.\n" +
                "4. **Placa de Controle e Relé**: O relé de 12V 16A da placa é excelente para acionamento de grandes lâmpadas em domótica e automação residencial."
            }
            else -> {
                "🛠️ **GUIA TÉCNICO CE RECICLETEC**:\n\n" +
                "Sua pergunta acerca de '${query}' é comum na bancada de eletrônica! Para prosseguir com segurança no conserto:\n" +
                "1. Verifique se o capacitor está descarregado.\n" +
                "2. Use o Multímetro na escala de continuidade para localizar fusíveis de vidro abertos ou chaves de segurança travadas.\n" +
                "3. Use a nossa aba de **Simulador de Teste** para confirmar se o comportamento e valores de resistência medidos indicam saúde ou danificação do componente.\n\n" +
                "Gostaria de saber como testar o Magnetron, Diodo, Trafo ou como reaproveitar o cobre dessas carcaças?"
            }
        }
    }
}

package com.example.data

// --- Data Models for Microwave Repair & Recycle ---

data class MicrowaveComponent(
    val id: String,
    val name: String,
    val portugueseName: String,
    val description: String,
    val function: String,
    val commonSymptoms: String,
    val testingInstructions: String,
    val expectedReadings: String,
    val recyclingInfo: String, // Eco-friendly recycling details
    val safetyHazard: String // Danger details
)

data class DiagnosticSymptom(
    val id: String,
    val title: String,
    val description: String,
    val possibleCauses: List<String>,
    val checklistSteps: List<String>,
    val recyclingEcoTip: String
)

data class SafetyStep(
    val id: Int,
    val title: String,
    val description: String,
    val isCrucial: Boolean = true
)

object RepairDataProvider {

    val safetySteps = listOf(
        SafetyStep(
            id = 1,
            title = "Desligar da Tomada",
            description = "NUNCA trabalhe com o micro-ondas ligado à rede elétrica. Desconecte o plugue completamente antes de remover o gabinete externo.",
            isCrucial = true
        ),
        SafetyStep(
            id = 2,
            title = "Remover Adornos e Usar EPI",
            description = "Retire relógios, anéis, pulseiras metálicas. Use óculos de proteção e calçados com isolamento de borracha.",
            isCrucial = true
        ),
        SafetyStep(
            id = 3,
            title = "Descarregar o Capacitor de Alta Voltagem",
            description = "O capacitor acumula até 4.000 Volts (letal). Mesmo fora da tomada, o capacitor pode reter essa voltagem. Use uma chave de fenda de alta isolação (1000V) com um cabo jacaré aterrado na carcaça do aparelho, ou conecte os dois terminais do capacitor por pelo menos 10 segundos para provocar o descarregamento seguro. Nunca pule esta etapa!",
            isCrucial = true
        ),
        SafetyStep(
            id = 4,
            title = "Cuidado com o Óxido de Berílio (Magnetron)",
            description = "A cerâmica rosa/branca da antena do Magnetron contém óxido de berílio. Se estiver trincada ou quebrada, NÃO inale poeira ou resíduos dela, pois é extremamente tóxica e carcinogênica. Manuseie com extremo cuidado.",
            isCrucial = true
        )
    )

    val components = listOf(
        MicrowaveComponent(
            id = "magnetron",
            name = "Magnetron",
            portugueseName = "Magnetron Osmar",
            description = "O coração do micro-ondas. Converte energia elétrica de alta voltagem em ondas de alta frequência (micro-ondas de 2.45 GHz) que agitam as moléculas de água dos alimentos, gerando calor.",
            function = "Geração de ondas eletromagnéticas de alta frequência.",
            commonSymptoms = "Aparelho funciona, o prato gira, acende a luz, mas não esquenta absolutamente nada. Pode gerar ronco forte.",
            testingInstructions = "Com o multímetro na escala de resistência mais baixa (200 ohms):\n1. Meça entre os dois terminais (filamentos) do magnetron. Deve dar um valor muito baixo (abaixo de 1 ohm).\n2. Meça entre qualquer um dos terminais e a carcaça de metal do Magnetron (escala máxima de Mohms). Deve dar infinito.",
            expectedReadings = "Terminais: ~0.2 a 0.9 Ω.\nTerminais para Carcaça: Infinito (OL). Qualquer leitura diferente indica curto-circuito interno.",
            recyclingInfo = "Contém ímãs de ferrite muito fortes e ligas de aço de alta qualidade. O CE RECICLETEC recomenda a desmontagem dos ímãs para projetos artesanais/motores e a triagem do cobre das bobinas do filamento. Se a cerâmica de berílio estiver danificada, descarte em local homologado para lixo eletrônico poluente.",
            safetyHazard = "Risco de emissão de radiação se operado com o gabinete aberto. Também possui isolantes cerâmicos tóxicos se partidos."
        ),
        MicrowaveComponent(
            id = "capacitor",
            name = "High-Voltage Capacitor",
            portugueseName = "Capacitor de Alta Voltagem",
            description = "Armazena a eletricidade alternada que vem do transformador e atua junto com o diodo para duplicar a voltagem para cerca de 4.000V CC para excitar o Magnetron.",
            function = "Filtragem e duplicação de voltagem (junto com o diodo de alta).",
            commonSymptoms = "Queima instantânea do fusível de alta ou de entrada; ronco extremamente forte ao tentar esquentar sem aquecimento.",
            testingInstructions = "AVISO: CERTIFIQUE-SE DE QUE ESTÁ DESCARREGADO!\nCom o multímetro analógico na escala X10k ou multímetro digital na escala de Megaohms (MΩ):\n1. Meça entre os terminais do capacitor. O valor deve subir momentaneamente (carregando com a bateria do teste) e depois retornar ao infinito.\n2. Meça de cada terminal para a carcaça do capacitor. Deve dar infinito.",
            expectedReadings = "Terminais: Resistencia infinita (após leve salto se digital). Possui resistor interno de ~10 MΩ para descarga automática, então a leitura entre terminais se estabilizará em torno de 10 MΩ.\nTerminais para carcaça: Infinito.",
            recyclingInfo = "Devem ser reciclados junto com lixo eletrônico de capacitores industriais. Modelos muito antigos podem conter óleo isolante prejudicial. Os modernos de alumínio são triturados para recuperação do metal.",
            safetyHazard = "Pode reter cargas elétricas letais (+2000V) por horas se o resistor de sangria interna falhar."
        ),
        MicrowaveComponent(
            id = "transformer",
            name = "High-Voltage Transformer (Trafo)",
            portugueseName = "Transformador de Alta Voltagem (Trafo)",
            description = "Transformador elevador robusto (composto por núcleo de ferro pesado). Eleva a tensão de entrada de 127V ou 220V para cerca de 2.000V AC.",
            function = "Elevação de tensão elétrica da rede residencial para alta voltagem.",
            commonSymptoms = "Fumaça com cheiro forte de verniz queimado, zumbido alto persistente, ou queima de fusível de entrada imediatamente após apertar o 'Ligar'.",
            testingInstructions = "Desconecte todos os fios do transformador!\n1. Bobinado Primário (terminais da parte inferior): Escala de 200 ohms, meça entre os dois pinos.\n2. Bobinado Secundário de alta (saída com terminal fêmea solitário): Escala de 200 ohms, meça entre o terminal fêmea de alta e a carcaça de metal do transformador.\n3. Bobinado de Filamento (fios grossos com saídas diretas): Escala 200 ohms, meça entre os conectores que saem do meio.",
            expectedReadings = "Primário: 1.0 a 3.0 Ω.\nSecundário de Alta: 60 a 120 Ω (da saída para a carcaça física).\nFilamento: Quase 0 Ω (~0.2 a 0.5 Ω).",
            recyclingInfo = "O Trafo é o grande campeão ecológico do CE RECICLETEC! Ele contém grandes quantidades de cobre puro de alta qualidade nos enrolamentos (às vezes alumínio revestido em aparelhos modernos baratos). No Centro de Reciclagem, desbobinamos o cobre para revenda, ou transformamos estes Trafos em máquinas de solda por ponto ecológicas ou gravadores de madeira (Lichtenberg) de forma pedagógica.",
            safetyHazard = "Gera corrente alternada extremamente forte e fatal (acima de 500mA em 2000V). NUNCA meça ligado à rede!"
        ),
        MicrowaveComponent(
            id = "diodo",
            name = "High-Voltage Diode",
            portugueseName = "Diodo de Alta Voltagem",
            description = "Uma pilha em série de vários diodos comuns de silício dentro de um mesmo invólucro para resistir a altas tensões. Permite a corrente fluir em apenas uma direção.",
            function = "Retificação e duplicação de tensão CC.",
            commonSymptoms = "Não esquenta, ronco forte metálico ao ligar, ou fusível de entrada/alta queimando continuamente.",
            testingInstructions = "Diodos de alta tensão possuem uma barreira de condução de ~6V a 10V, logo, a bateria de 9V do multímetro comum não consegue testá-lo diretamente na escala de diodo convencional (marcará aberto em ambos os lados).\nComo testar: Monte um circuito série com uma bateria de 9V ou 12V e uma lâmpada ou meça usando o multímetro em série. Se conduzir em apenas um sentido, o diodo está ótimo.",
            expectedReadings = "Montagem série com bateria: Lâmpada acende em um sentido, e apaga ao inverter a polaridade do diodo. Se o diodo der continuidade direta no multímetro comum (escala de bip), ele está em curto-circuito.",
            recyclingInfo = "Contém silício, cobre nos terminais e invólucro polimérico. Reciclagem química de semicondutores.",
            safetyHazard = "Se entrar em curto-circuito, sobrecarregará o capacitor e o trafo."
        ),
        MicrowaveComponent(
            id = "door_switches",
            name = "Door Microswitches",
            portugueseName = "Microchaves de Segurança da Porta",
            description = "Geralmente um conjunto de 3 microchaves (Primária, Secundária e Monitoradora) posicionadas no trinco da porta para garantir que o micro-ondas só funcione com a porta 100% fechada, evitando vazamento de radiação.",
            function = "Intertravamento de segurança mecânico-elétrico.",
            commonSymptoms = "Prato gira maluco ao abrir a porta, lâmpada acende mas painel desliga, ou o fusível de entrada queima instantaneamente quando a porta é aberta ou fechada.",
            testingInstructions = "Desconecte as chaves. Utilize a escala de continuidade ou bip do multímetro digital:\n1. Chave Normalmente Aberta (NO/NA): Deve dar infinito livre, e bipar/dar zero ao pressionar o pino plástico.\n2. Chave Normalmente Fechada (NC/NF): Deve dar bip/zero ohms livre, e infinito ao pressionar o pino.",
            expectedReadings = "Condução perfeita (0 Ω) quando fechada e resistência infinita (OL) quando aberta de acordo com a função da chave.",
            recyclingInfo = "Contém contatos de prata de alta pureza e latão/cobre. Um ótimo componente para ser recuperado e reutilizado em projetos robóticos e automação doméstica de baixa potência no CE RECICLETEC.",
            safetyHazard = "Chaves desalinhadas podem derreter ou causar curto deliberado (curto de proteção monitorado) que queima o fusível."
        ),
        MicrowaveComponent(
            id = "fuse",
            name = "Input & HV Fuses",
            portugueseName = "Fusíveis (Entrada e Alta Tensão)",
            description = "Dispositivos de segurança projetados para se partirem ou queimarem caso a corrente ultrapasse o limite seguro, protegendo circuitos caros de incêndios e danos catastróficos.",
            function = "Proteção contra sobrecorrente elétrica.",
            commonSymptoms = "Fusível de Entrada (20A cerâmico): Aparelho completamente apagado, morto.\nFusível de Alta (0.7A em cápsula): Tudo liga normal, prato gira, contagem corre, mas não esquenta.",
            testingInstructions = "Com o multímetro na escala de continuidade de sinal sonoro (bip):\nMeça tocando as pontas de prova em cada extremidade metálica do fusível.",
            expectedReadings = "Bip sonoro e valor próximo a 0 Ω. Se der OL (infinito), o fusível está aberto (queimado) e deve ser substituído. Nunca substitua por fios ou papel alumínio!",
            recyclingInfo = "As tampas metálicas são de liga de cobre/zinco/estanho. O vidro/cerâmica de descarte seguro.",
            safetyHazard = "Fios improvisados no lugar do fusível podem causar incêndios na fiação residencial ou explodir o transformador."
        )
    )

    val symptoms = listOf(
        DiagnosticSymptom(
            id = "s_nao_liga",
            title = "Aparelho Completamente Morto (Não Liga)",
            description = "O micro-ondas está conectado à tomada, mas nenhuma luz acende no painel, nenhum bip soa e nada responde.",
            possibleCauses = listOf("fuse", "door_switches"),
            checklistSteps = listOf(
                "Testar a tomada elétrica com outro eletrodoméstico para confirmar energia.",
                "Inspecionar visualmente o cabo de força do micro-ondas em busca de cortes ou amassados.",
                "Remover o gabinete (com segurança!) e testar a continuidade do FUSÍVEL CERÂMICO DE ENTRADA (geralmente 20A).",
                "Verificar o termostato de segurança montado sobre a cavidade ou sobre o magnetron (deve dar continuidade).",
                "Verificar as microchaves de contato da porta para ver se não há suporte plástico quebrado impedindo o acionamento."
            ),
            recyclingEcoTip = "Se o aparelho for descartado por painel queimado de difícil reposição, a placa eletrônica contém contatos de cobre, relés reaproveitáveis e displays LED verdes de alta luminosidade."
        ),
        DiagnosticSymptom(
            id = "s_nao_esquenta",
            title = "Tudo Funciona, mas Não Esquenta Alimentos",
            description = "O prato gira, a luz acende, o painel conta o tempo normalmente, mas a água ou comida sai completamente fria após o ciclo.",
            possibleCauses = listOf("magnetron", "capacitor", "diodo", "transformer"),
            checklistSteps = listOf(
                "Verificar se o silêncio é incomum ou se há um ronco baixo. Um ronco indica esforço de alta voltagem.",
                "Inspecionar o fusível de alta tensão (se houver, dentro de uma cápsula plástica preta entre o trafo e o capacitor).",
                "Medir a continuidade dos filamentos do Magnetron e se não há fuga para a terra.",
                "Inspecionar visualmente a antena do Magnetron (ponteira metálica). Se estiver derretida ou queimada, requer troca.",
                "Testar o Diodo de Alta Voltagem para garantir que não está em curto-circuito.",
                "Testar o Capacitor de Alta Voltagem para comprovar isolação e capacitância."
            ),
            recyclingEcoTip = "Micro-ondas que não esquentam geralmente têm falhas pontuais no diodo de R$ 10 ou no fusível de alta de R$ 5. Reparar este defeito evita o descarte prematuro de 15kg de metal e eletrônicos!"
        ),
        DiagnosticSymptom(
            id = "s_fagulhas",
            title = "Soltando Faíscas/Fagulhas na Cavidade Interna",
            description = "Ao ligar o aparelho, ouve-se estalos de curto-circuito e enxerga-se clarões de faíscas dentro do micro-ondas. Desligue imediatamente!",
            possibleCauses = listOf("magnetron"),
            checklistSteps = listOf(
                "Retirar o prato giratório e inspecionar a cavidade interna buscando ferrugem exposta ou pintura descascada.",
                "Inspecionar a placa de mica protetora da guia de ondas (na parede lateral direita). Se estiver preta, queimada ou com furos, retire-a.",
                "Observar se o usuário inseriu objetos metálicos, talheres ou potes com frisos de alumínio/ouro.",
                "Verificar a ponteira da antena do Magnetron se não está carbonizada devido ao acúmulo de gordura por falta da mica."
            ),
            recyclingEcoTip = "A placa de mica queimada pode ser cortada de uma placa maior de mica virgem bem barata. Pratos de vidro de micro-ondas descartados são vidro temperado excelente para decoração ou fruteiras ecológicas."
        ),
        DiagnosticSymptom(
            id = "s_prato_nao_gira",
            title = "Prato Não Gira ou Luz Não Acende",
            description = "O micro-ondas aquece o alimento, mas o prato de vidro permanece parado ou a lâmpada interna de visualização fica apagada.",
            possibleCauses = listOf("door_switches"),
            checklistSteps = listOf(
                "Retirar o acoplador em trevo de plástico sob o prato de vidro e verificar se não está rachado ou espanado.",
                "Medir com multímetro (escala de tensão AC) se chega energia nos terminais do motor do prato na parte inferior do aparelho durente o funcionamento.",
                "Girar o prato com as mãos para verificar se o motor não está travado mecanicamente por gordura acumulada.",
                "Substituir a lâmpada de filamento (geralmente T25 de 20W/25W) ou motor do prato se queimados."
            ),
            recyclingEcoTip = "Os pequenos motores síncronos de prato de micro-ondas (conhecidos por girarem a 4-6 RPM) funcionam direto em 110V/220V AC e possuem alto torque! No CE RECICLETEC, nós os reutilizamos para criar mini-churrasqueiras giratórias, incubadoras ecológicas de ovos e expositores de balcão rotativos!"
        ),
        DiagnosticSymptom(
            id = "s_painel_morto",
            title = "Painel Sensível ao Toque Sem Resposta",
            description = "A tela acende, mostra o relógio, mas os botões de ligar, números ou início simplesmente não respondem ao toque físico.",
            possibleCauses = listOf("door_switches"),
            checklistSteps = listOf(
                "Limpar bem a superfície externa para retirar gordura acumulada que isola a condução dos dedos.",
                "Inspecionar o cabo flat da membrana do painel. Desencaixar do slot da placa eletrônica, limpar as trilhas com borracha macia e engatar de volta.",
                "Testar o acionamento por membrana teclado novo. Caso persista, pode ser defeito no microprocessador da placa controladora."
            ),
            recyclingEcoTip = "Problemas na membrana plástica de botões podem ser consertados trocando a película autoadesiva (super barata). O CE RECICLETEC incentiva a adaptação de chaves tácteis físicas soldadas por trás do painel para reviver membranas raras!"
        )
    )
}
